Award Winners
	The folder contains three files that can be used to replicate the example about awards’ winners in MongoDB.
	- winners_input_file.txt contains an array of objects which can be used as input
	- schema_validator.txt contains the schema validator which can be used to impose constraints on documents’ structure
	- winners_pipelines.txt contains some aggregation pipelines which can be executed over the collection

Movielens directory:
	The folder contains a python notebook which describe the process of retrieving data sources to create an integrated document-based database in MongoDB. The notebook also contains some queries and aggregation pipelines.